


class Slingshot {

    constructor(
        engine,
        world,
        canvas,
        anchorX,
        anchorY
    ) {

        this.engine = engine;
        this.world = world;
        this.canvas = canvas;

        this.anchor = {
            x: anchorX,
            y: anchorY
        };

        this.maxPullDistance = 100;

        this.currentProjectile = null;

        this.elastic = null;


        // -------------------------
        // Mouse
        // -------------------------

        const mouse = Mouse.create(
            this.canvas
        );


        this.mouseConstraint =
            MouseConstraint.create(
                this.engine,
                {
                    mouse: mouse,

                    constraint: {
                        stiffness: 0.2,

                        render: {
                            visible: false
                        }
                    }
                }
            );


        Composite.add(
            this.world,
            this.mouseConstraint
        );
    }


    // -------------------------
    // Attach projectile
    // -------------------------

    attachProjectile(projectile) {

        this.currentProjectile = projectile;


        // Create elastic constraint
        this.elastic = Constraint.create({

            pointA: {
                x: this.anchor.x,
                y: this.anchor.y
            },

            bodyB: projectile,

            pointB: {
                x: 0,
                y: 0
            },

            stiffness: 0.08,

            damping: 0.03,

            render: {
                visible: true
            }
        });


        Composite.add(
            this.world,
            this.elastic
        );
    }


    // -------------------------
    // Remove elastic
    // -------------------------

    releaseProjectile() {

        if (this.elastic) {

            Composite.remove(
                this.world,
                this.elastic
            );

            this.elastic = null;
        }

        this.currentProjectile = null;
    }


    // -------------------------
    // Limit projectile movement
    // -------------------------

    limitPullDistance() {

        if (!this.currentProjectile) {
            return;
        }


        const dragVector =
            Vector.sub(
                this.currentProjectile.position,
                this.anchor
            );


        const distance =
            Vector.magnitude(
                dragVector
            );


        if (
            distance >
            this.maxPullDistance
        ) {

            const direction =
                Vector.normalise(
                    dragVector
                );


            const limited =
                Vector.mult(
                    direction,
                    this.maxPullDistance
                );


            const position =
                Vector.add(
                    this.anchor,
                    limited
                );


            Matter.Body.setPosition(
                this.currentProjectile,
                position
            );
        }
    }


    // -------------------------
    // Draw slingshot
    // -------------------------

    render(ctx) {

        ctx.save();


        // =========================
        // Slingshot wooden frame
        // =========================

        ctx.strokeStyle = '#8b4513';

        ctx.lineWidth = 12;

        ctx.lineCap = 'round';


        // Left arm
        ctx.beginPath();

        ctx.moveTo(
            this.anchor.x - 35,
            this.anchor.y + 70
        );

        ctx.lineTo(
            this.anchor.x,
            this.anchor.y
        );

        ctx.stroke();


        // Right arm
        ctx.beginPath();

        ctx.moveTo(
            this.anchor.x + 35,
            this.anchor.y + 70
        );

        ctx.lineTo(
            this.anchor.x,
            this.anchor.y
        );

        ctx.stroke();


        // Handle
        ctx.beginPath();

        ctx.moveTo(
            this.anchor.x - 35,
            this.anchor.y + 70
        );

        ctx.lineTo(
            this.anchor.x + 35,
            this.anchor.y + 70
        );

        ctx.stroke();


        // =========================
        // Elastic bands
        // =========================

        if (
            this.currentProjectile
        ) {

            const position =
                this.currentProjectile.position;


            ctx.strokeStyle = '#d97706';

            ctx.lineWidth = 5;


            // Left band
            ctx.beginPath();

            ctx.moveTo(
                this.anchor.x - 10,
                this.anchor.y + 10
            );

            ctx.lineTo(
                position.x,
                position.y
            );

            ctx.stroke();


            // Right band
            ctx.beginPath();

            ctx.moveTo(
                this.anchor.x + 10,
                this.anchor.y + 10
            );

            ctx.lineTo(
                position.x,
                position.y
            );

            ctx.stroke();
        }


        ctx.restore();
    }
}