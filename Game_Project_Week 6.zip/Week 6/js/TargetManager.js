

class TargetManager {

    constructor(engine, world) {

        this.engine = engine;
        this.world = world;

        this.targets = [];
        this.destroyedCount = 0;
        this.totalTargets = 0;

        this.COLLISION_CATEGORY = {
            PROJECTILE: 0x0001,
            BLOCK: 0x0002,
            TARGET: 0x0004
        };

        this.initCollisionEvents();
    }


    createTarget(
        positionX,
        positionY,
        radius = 20
    ) {

        const target =
            Bodies.circle(
                positionX,
                positionY,
                radius,
                {
                    density: 0.002,
                    friction: 0.6,
                    restitution: 0.2,

                    collisionFilter: {
                        category:
                            this.COLLISION_CATEGORY.TARGET,

                        mask: 0xFFFF
                    },

                    render: {
                        fillStyle: '#10b981'
                    }
                }
            );

        target.isTarget = true;
        target.isDestroyed = false;
        target.trackingHeight = positionY;

        this.targets.push(target);
        this.totalTargets++;

        Composite.add(
            this.world,
            target
        );

        return target;
    }


    initCollisionEvents() {

        Events.on(
            this.engine,
            'collisionStart',
            (event) => {

                event.pairs.forEach(pair => {

                    const bodyA = pair.bodyA;
                    const bodyB = pair.bodyB;

                    this.checkTargetDamage(
                        bodyA,
                        bodyB
                    );

                    this.checkTargetDamage(
                        bodyB,
                        bodyA
                    );
                });
            }
        );
    }


    checkTargetDamage(
        targetCandidate,
        collider
    ) {

        if (
            targetCandidate.isTarget &&
            !targetCandidate.isDestroyed
        ) {

            const speed =
                Vector.magnitude(
                    collider.velocity
                );

            if (speed > 3.5) {
                this.flagDestroyed(
                    targetCandidate
                );
            }
        }
    }


    flagDestroyed(target) {

        target.isDestroyed = true;

        target.render.fillStyle =
            '#6b7280';

        this.destroyedCount++;

        console.log(
            'Target destroyed!'
        );
    }


    updateTracking() {

        const bounds = {
            width: 800,
            height: 600,
            margin: 50
        };

        for (
            let index = this.targets.length - 1;
            index >= 0;
            index--
        ) {

            const target =
                this.targets[index];

            target.trackingHeight =
                target.position.y;

            const isOutOfBounds =
                target.position.x <
                    -bounds.margin ||

                target.position.x >
                    bounds.width +
                    bounds.margin ||

                target.position.y >
                    bounds.height +
                    bounds.margin;

            if (isOutOfBounds) {

                if (!target.isDestroyed) {
                    this.destroyedCount++;
                }

                Composite.remove(
                    this.world,
                    target
                );

                this.targets.splice(
                    index,
                    1
                );
            }
        }
    }
}