

class Environment {

    constructor(world) {

        this.world = world;
        this.boundaries = [];

        this.createBoundaries();
    }


    createBoundaries() {

        const options = {

            isStatic: true,

            friction: 0.8,

            restitution: 0.2,

            render: {
                fillStyle: '#2d3748',
                strokeStyle: '#4a5568',
                lineWidth: 2
            }
        };


        // Ground
        const ground = Bodies.rectangle(
            400,
            580,
            800,
            40,
            options
        );


        // Left wall
        const leftWall = Bodies.rectangle(
            10,
            300,
            20,
            600,
            options
        );


        // Right wall
        const rightWall = Bodies.rectangle(
            790,
            300,
            20,
            600,
            options
        );


        // Ceiling
        const ceiling = Bodies.rectangle(
            400,
            10,
            800,
            20,
            options
        );


        // Platform
        const platform = Bodies.rectangle(
            550,
            400,
            200,
            20,
            options
        );


        this.boundaries = [
            ground,
            leftWall,
            rightWall,
            ceiling,
            platform
        ];


        Composite.add(
            this.world,
            this.boundaries
        );
    }
}