

class StructureBuilder {

    constructor(world) {

        this.world = world;
        this.dynamicBlocks = [];
    }


    static MATERIALS = {

        WOOD: {
            density: 0.001,
            friction: 0.5,
            restitution: 0.15,

            render: {
                fillStyle: '#c4a482'
            }
        },


        STONE: {
            density: 0.0025,
            friction: 0.7,
            restitution: 0.05,

            render: {
                fillStyle: '#708090'
            }
        },


        ICE: {
            density: 0.0008,
            friction: 0.05,
            restitution: 0.1,

            render: {
                fillStyle: '#a5f2f3'
            }
        }
    };


    createBlock(
        x,
        y,
        width,
        height,
        material = StructureBuilder.MATERIALS.WOOD,
        shape = 'rectangle'
    ) {

        const options = {

            density: material.density,

            friction: material.friction,

            restitution: material.restitution,

            frictionAir: 0.01,

            render: {
                fillStyle: material.render.fillStyle
            }
        };


        let block;


        if (shape === 'circle') {

            block = Bodies.circle(
                x,
                y,
                width / 2,
                options
            );

        } else {

            block = Bodies.rectangle(
                x,
                y,
                width,
                height,
                options
            );
        }


        this.dynamicBlocks.push(block);

        Composite.add(
            this.world,
            block
        );


        return block;
    }


    buildTower(baseX, baseY) {

        // Stone columns
        this.createBlock(
            baseX - 40,
            baseY - 40,
            20,
            80,
            StructureBuilder.MATERIALS.STONE
        );


        this.createBlock(
            baseX + 40,
            baseY - 40,
            20,
            80,
            StructureBuilder.MATERIALS.STONE
        );


        // First beam
        this.createBlock(
            baseX,
            baseY - 90,
            120,
            20,
            StructureBuilder.MATERIALS.WOOD
        );


        // Upper columns
        this.createBlock(
            baseX - 25,
            baseY - 130,
            15,
            60,
            StructureBuilder.MATERIALS.WOOD
        );


        this.createBlock(
            baseX + 25,
            baseY - 130,
            15,
            60,
            StructureBuilder.MATERIALS.WOOD
        );


        // Upper beam
        this.createBlock(
            baseX,
            baseY - 170,
            80,
            15,
            StructureBuilder.MATERIALS.WOOD
        );


        // Ice target
        this.createBlock(
            baseX,
            baseY - 200,
            30,
            30,
            StructureBuilder.MATERIALS.ICE,
            'circle'
        );
    }


    renderDebug(ctx) {

        ctx.save();

        this.dynamicBlocks.forEach(block => {

            // Center marker
            ctx.fillStyle = '#8c02e2';

            ctx.beginPath();

            ctx.arc(
                block.position.x,
                block.position.y,
                3,
                0,
                Math.PI * 2
            );

            ctx.fill();


            // Direction line
            ctx.strokeStyle = '#00ffcc';

            ctx.lineWidth = 1;

            ctx.beginPath();

            ctx.moveTo(
                block.position.x,
                block.position.y
            );

            ctx.lineTo(
                block.position.x +
                Math.cos(block.angle) * 15,

                block.position.y +
                Math.sin(block.angle) * 15
            );

            ctx.stroke();
        });

        ctx.restore();
    }
}