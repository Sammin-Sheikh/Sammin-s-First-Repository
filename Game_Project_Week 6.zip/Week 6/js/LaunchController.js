const {
    Body,
} = Matter;

class LaunchController {
    constructor(world, slingshot, totalProjectiles = 3) {
        this.world = world;
        this.slingshot = slingshot;

        this.totalProjectiles = totalProjectiles;
        this.remainingProjectiles = totalProjectiles;

        this.activeProjectile = null;
        this.launchedProjectiles = [];

        this.isLaunching = false;
        this.reloadDelay = 1500;

        // Controls launch speed
        this.launchSpeed = 0.25;

        this.initReleaseListener();
    }

    loadNextProjectile() {
        if (this.remainingProjectiles <= 0) {
            console.log("No projectiles remaining.");
            return;
        }

        const anchor = this.slingshot.anchor;

        const projectile = Bodies.circle(
            anchor.x,
            anchor.y,
            16,
            {
                density: 0.004,
                restitution: 0.35,
                friction: 0.1,
                frictionAir: 0.005,

                render: {
                    fillStyle: "#ef4444"
                }
            }
        );

        Composite.add(this.world, projectile);

        this.slingshot.attachProjectile(projectile);

        this.activeProjectile = projectile;
        this.remainingProjectiles--;

        console.log(
            "Projectile loaded. Remaining:",
            this.remainingProjectiles
        );
    }

    initReleaseListener() {
        Events.on(
            this.slingshot.mouseConstraint,
            "mouseup",
            () => {

                if (this.isLaunching) {
                    return;
                }

                if (!this.activeProjectile) {
                    return;
                }

                this.launch();
            }
        );
    }

    launch() {

        const projectile = this.activeProjectile;

        if (!projectile) {
            return;
        }

        this.isLaunching = true;

        const anchor = this.slingshot.anchor;

        // Direction from projectile back toward slingshot anchor
        const launchVector = Vector.sub(
            anchor,
            projectile.position
        );

        // Calculate launch velocity
        const launchVelocity = Vector.mult(
            launchVector,
            this.launchSpeed
        );

        console.log(
            "Launch velocity:",
            launchVelocity
        );

        // Remove elastic
        this.slingshot.releaseProjectile();

        // Give projectile its launch velocity
        Body.setVelocity(
            projectile,
            launchVelocity
        );

        this.launchedProjectiles.push(projectile);

        this.activeProjectile = null;

        console.log("Projectile launched!");

        setTimeout(() => {

            this.isLaunching = false;

            if (this.remainingProjectiles > 0) {
                this.loadNextProjectile();
            }

        }, this.reloadDelay);
    }
}