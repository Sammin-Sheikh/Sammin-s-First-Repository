const {
    Engine,
    Render,
    Runner,
    Events,
    Constraint,
    Mouse,
    MouseConstraint,
    Vector,
    Composite,
    Bodies,
} = Matter;



class GameEngine {

    constructor(canvasId) {

        this.canvas =
            document.getElementById(
                canvasId
            );


        if (!this.canvas) {

            throw new Error(
                'Canvas not found!'
            );
        }


        // Engine
        this.engine =
            Engine.create();


        // World
        this.world =
            this.engine.world;


        // Renderer
        this.render =
            Render.create({

                canvas: this.canvas,

                engine: this.engine,

                options: {
                    width: 800,
                    height: 600,

                    wireframes: false,

                    background: '#1a1a1a'
                }
            });


        // Runner
        this.runner =
            Runner.create();
    }


    start() {

        Render.run(
            this.render
        );


        Runner.run(
            this.runner,
            this.engine
        );


        console.log(
            'Game started!'
        );
    }


    stop() {

        Render.stop(
            this.render
        );

        Runner.stop(
            this.runner
        );
    }
}


// =========================
// MAIN GAME
// =========================

window.addEventListener(
    'DOMContentLoaded',
    () => {

        try {

            // ---------------------
            // Game Engine
            // ---------------------

            const game =
                new GameEngine(
                    'gameCanvas'
                );


            // ---------------------
            // Environment
            // ---------------------

            const environment =
                new Environment(
                    game.world
                );


            // ---------------------
            // Tower
            // ---------------------

            const builder =
                new StructureBuilder(
                    game.world
                );


            builder.buildTower(
                550,
                390
            );


            // ---------------------
            // Slingshot
            // ---------------------

            const slingshot =
                new Slingshot(
                    game.engine,
                    game.world,
                    game.canvas,
                    150,
                    420
                );


            // ---------------------
            // Launch Controller
            // ---------------------

            const launcher =
                new LaunchController(
                    game.world,
                    slingshot,
                    3
                );


            // Load first projectile
            launcher.loadNextProjectile();


            // ---------------------
            // Week 6 Target Manager
            // ---------------------

            const targetManager =
                new TargetManager(
                    game.engine,
                    game.world
                );


            // Create targets

            targetManager.createTarget(
                550,
                200
            );


            targetManager.createTarget(
                550,
                320
            );


            // ---------------------
            // Target Tracking
            // ---------------------

            Events.on(
                game.engine,
                'afterUpdate',
                () => {

                    targetManager.updateTracking();

                }
            );


            // ---------------------
            // Custom rendering
            // ---------------------

            Events.on(
                game.render,
                'afterRender',
                () => {

                    const ctx =
                        game.render.context;


                    // Draw slingshot
                    slingshot.render(
                        ctx
                    );


                    // Draw debug markers
                    builder.renderDebug(
                        ctx
                    );
                }
            );


            // ---------------------
            // Mouse movement
            // ---------------------

            Events.on(
                slingshot.mouseConstraint,
                'mousemove',
                () => {

                    slingshot.limitPullDistance();
                }
            );


            // ---------------------
            // Start
            // ---------------------

            game.start();


            console.log(
                'Week 6 loaded successfully!'
            );


        } catch (error) {

            console.error(
                'Game Error:',
                error
            );
        }
    }
);